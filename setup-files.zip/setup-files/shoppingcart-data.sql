-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Mar 02, 2017 at 04:11 PM
-- Server version: 5.6.28
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shoppingcart`
--
CREATE DATABASE IF NOT EXISTS `shoppingcart` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `shoppingcart`;

-- --------------------------------------------------------

--
-- Table structure for table `billing`
--

CREATE TABLE `billing` (
  `billing_id` int(11) NOT NULL,
  `billing_username` varchar(50) NOT NULL,
  `billing_name` text NOT NULL,
  `billing_street` longtext NOT NULL,
  `billing_city` text NOT NULL,
  `billing_state` varchar(30) NOT NULL,
  `billing_zip` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `billing`
--

INSERT INTO `billing` (`billing_id`, `billing_username`, `billing_name`, `billing_street`, `billing_city`, `billing_state`, `billing_zip`) VALUES
(1, 'bbailey', 'Brooke Bailey', '51 East Market Street', 'Harrisonburg', 'VA', 11814),
(3, 'bbailey', 'Sarah', '2343 East Wayward', 'San Antionio', 'TX', 342342),
(4, 'SarahB', 'Sarah', '567 East Market Street', 'Denver', 'CO', 45678),
(5, 'Mathias-the-great', 'Mathias Walters', '5689 East Side Highway', 'Harrisonburg', 'VA', 22801);

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `cart_id` int(255) NOT NULL,
  `username` varchar(50) NOT NULL,
  `quantity` text NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_option` text NOT NULL,
  `product_size` text NOT NULL,
  `order_id` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`cart_id`, `username`, `quantity`, `product_id`, `product_option`, `product_size`, `order_id`) VALUES
(1, 'bbailey', '1', 567683, '', '', 24),
(12, 'bbailey', '3', 782030, 'Blue', 'XS', 15),
(13, 'bbailey', '2', 782030, 'Black', 'SM', 24),
(24, 'bbailey', '5', 678096, 'Orange', '', 26),
(28, 'bbailey', '1', 567683, '', '', 28),
(29, 'bbailey', '1', 243489, '', '4', 39),
(30, 'bbailey', '1', 373940, '', 'SMALL', 39),
(31, 'bbailey', '1', 243489, '', '', 0),
(35, 'bbailey', '1', 342527, '', 'SMALL', 0),
(38, 'bbailey', '1', 567683, '', '', 0),
(39, 'SarahB', '1', 243489, '', '4', 40),
(41, 'SarahB', '3', 466343, '', 'LARGE', 40),
(42, 'SarahB', '1', 782030, '', 'X-SMALL', 40),
(43, 'cuy-girl', '1', 342527, '', 'SMALL', 0);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `billing_id` int(11) NOT NULL,
  `shipping_id` int(11) NOT NULL,
  `payment_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `total` float NOT NULL,
  `complete` tinyint(1) NOT NULL DEFAULT '0',
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `billing_id`, `shipping_id`, `payment_id`, `username`, `total`, `complete`, `date`) VALUES
(15, 1, 1, 4, 'bbailey', 153.89, 1, '2017-02-17 21:22:08'),
(24, 1, 1, 4, 'bbailey', 153.89, 0, '2017-02-19 14:34:14'),
(26, 1, 2, 1, 'bbailey', 153.89, 0, '2017-02-20 17:18:45'),
(28, 1, 1, 1, 'bbailey', 178.07, 0, '2017-02-23 20:10:37'),
(29, 1, 1, 1, 'bbailey', 178.07, 0, '2017-02-23 20:28:15'),
(30, 1, 1, 1, 'bbailey', 178.07, 0, '2017-02-23 20:28:28'),
(31, 1, 1, 1, 'bbailey', 178.07, 0, '2017-02-23 20:28:51'),
(32, 1, 1, 1, 'bbailey', 178.07, 0, '2017-02-23 20:28:55'),
(33, 1, 1, 1, 'bbailey', 178.07, 0, '2017-02-23 20:31:12'),
(34, 1, 1, 1, 'bbailey', 178.07, 0, '2017-02-23 20:31:44'),
(35, 1, 1, 1, 'bbailey', 178.07, 0, '2017-02-23 20:32:12'),
(36, 1, 1, 1, 'bbailey', 178.07, 0, '2017-02-23 20:32:17'),
(37, 1, 1, 1, 'bbailey', 379.73, 0, '2017-02-23 20:45:11'),
(38, 1, 1, 1, 'bbailey', 379.73, 0, '2017-02-23 20:46:28'),
(39, 1, 1, 1, 'bbailey', 379.73, 0, '2017-02-23 20:53:25'),
(40, 4, 3, 5, 'SarahB', 249.2, 0, '2017-03-02 20:12:08');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `payment_id` int(11) NOT NULL,
  `payment_username` varchar(30) NOT NULL,
  `payment_type` varchar(20) NOT NULL,
  `payment_card_number` bigint(11) NOT NULL,
  `payment_pin` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`payment_id`, `payment_username`, `payment_type`, `payment_card_number`, `payment_pin`) VALUES
(1, 'bbailey', 'Discover', 123456786543, 333),
(4, 'bbailey', 'Visa', 65748392756, 333),
(5, 'SarahB', 'Discover', 3343223, 324),
(6, 'Mathias-the-great', 'Master Card', 27342303998, 356);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_name` varchar(700) DEFAULT NULL,
  `product_id` int(11) NOT NULL,
  `product_description` longtext NOT NULL,
  `product_stock` int(11) NOT NULL,
  `product_price` varchar(7) NOT NULL,
  `product_options` text NOT NULL,
  `size` text NOT NULL,
  `short_description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_name`, `product_id`, `product_description`, `product_stock`, `product_price`, `product_options`, `size`, `short_description`) VALUES
('Womens Adidas Running Shoe', 243489, 'Sirloin pork short loin, capicola swine cupim andouille shank prosciutto ground round turducken cow turkey. Bacon bresaola salami doner landjaeger. Strip steak sirloin doner alcatra ball tip, turkey pork belly shank shankle beef cupim jowl bacon. Boudin andouille shoulder tail sausage pig kevin drumstick beef ham spare ribs frankfurter.', 0, '153.46', '', '4:5:6:7:8:9:10', 'Strip steak sirloin doner alcatra ball tip, turkey pork belly shank shankle beef cupim jowl bacon. '),
('Womens Tek Gear Running Shorts', 342527, 'Cow alcatra cupim, fatback pork loin ground round ball tip ham short loin meatloaf tenderloin sirloin pig hamburger. Biltong venison pork belly cupim, leberkas capicola porchetta andouille short ribs. Swine andouille sausage pork chop venison short ribs. Kielbasa turkey brisket tenderloin bresaola corned beef biltong kevin, pig tri-tip ground round beef ribs pork loin jerky venison. Tongue pork shankle kielbasa, pancetta strip steak kevin.\r\n\r\n', 89, '8.76', 'Blue/Black:Pink/Purple:Green/Black:White/Blue', 'SMALL:MEDIUM:LARGE', 'Tongue pork shankle kielbasa, pancetta strip steak kevin.'),
('SONOMA Sweatshirt', 373940, 'Bacon ipsum dolor amet turducken leberkas burgdoggen biltong pork shankle sirloin swine short loin ham shoulder. Cow chuck kielbasa fatback, filet mignon prosciutto corned beef shoulder. Shoulder bacon jerky, andouille jowl shankle swine drumstick short ribs turducken pastrami capicola brisket. Filet mignon pork loin kevin ground round cupim. Sausage cow pork chop doner venison biltong turducken. Turducken bacon frankfurter jowl jerky landjaeger.\r\n\r\nTurducken ribeye spare ribs, jerky ball tip fatback shank chuck beef ribs drumstick kielbasa doner. Turkey brisket kielbasa shoulder filet mignon cupim frankfurter tail beef. Drumstick ham hock turkey venison strip steak leberkas, bresaola short ribs. Ham hock swine turkey shank andouille pork loin beef pork kielbasa tenderloin. Ball tip flank cupim, kielbasa jerky turkey doner. Rump alcatra shankle kevin pancetta sausage. Leberkas cow beef kielbasa strip steak filet mignon kevin.\r\n\r\n', 6, '20.76', 'Orange:Blue:Pink:Purple:Black:White:Yellow', 'SMALL:MDEDIUM:LARGE', 'Bacon ipsum dolor amet turducken leberkas burgdoggen biltong pork shankle sirloin swine short loin ham shoulder.\r\n'),
('ELLE Long Sleeved Sweater', 457590, 'Beef ribs hamburger t-bone boudin andouille. Short loin brisket drumstick corned beef sausage burgdoggen leberkas ham hock meatball strip steak sirloin beef ribs. Jerky burgdoggen doner sausage tongue ball tip. Picanha capicola landjaeger bacon hamburger. Leberkas ham andouille, drumstick chuck venison alcatra swine. Short loin chicken pancetta jowl pork kielbasa.\r\n\r\nSpare ribs short ribs meatloaf cupim capicola chuck frankfurter beef ribs. Brisket bresaola ribeye ham t-bone. Pancetta ham tri-tip pork belly biltong. Pig ham shoulder, pork loin frankfurter strip steak alcatra short loin sausage. Pork belly short loin pork, salami tail ham pancetta frankfurter.\r\n\r\n', 50, '4.78', '', 'SMALL:MEDIUM:LARGE', 'Chicken chuck biltong doner meatloaf capicola kielbasa. Ground round beef ribs cupim pork loin bacon flank. '),
('Nike Running Capris', 466343, 'Sausage burgdoggen shoulder, jerky tail flank short ribs shank porchetta cow. Frankfurter swine jowl short loin salami pork belly pork short ribs meatloaf ham hock shoulder. Meatball flank brisket short ribs. Porchetta ground round doner pastrami landjaeger, brisket jowl. Rump strip steak leberkas, ribeye spare ribs hamburger pig kevin t-bone beef ribs bresaola flank corned beef prosciutto cow.\r\n\r\nKevin shank brisket ribeye bresaola burgdoggen chicken short ribs andouille alcatra pancetta. Doner corned beef pig alcatra short loin strip steak tri-tip boudin turducken. Picanha chicken pork chop, tongue fatback turkey rump. Cow corned beef pork, biltong pancetta leberkas cupim meatball. Hamburger bresaola sirloin, tenderloin cupim pork belly ham hock alcatra tongue jerky beef ribs bacon turducken. Porchetta sausage hamburger, alcatra jerky meatloaf pork belly drumstick.\r\n\r\nBiltong rump tail, spare ribs sausage chuck jerky capicola ribeye drumstick. Pork belly alcatra ground round, spare ribs frankfurter shank flank kielbasa tail tri-tip andouille short loin. Pancetta pig picanha, cupim biltong kevin bresaola chicken andouille pork loin tri-tip porchetta filet mignon. Drumstick doner cupim turducken shank chuck pork loin shankle rump corned beef pancetta alcatra pig. Swine jowl shank biltong cupim pork sausage doner short ribs ground round turducken tenderloin. Pig sausage spare ribs cupim capicola tenderloin.', 42, '14.56', 'Black/Blue:Black/Orange:Blue/Grey:Black/White', 'SMALL:MEDIUM:LARGE', 'Pig sausage spare ribs cupim capicola tenderloin.'),
('Womens Tek Gear Shapewear Shorts', 523241, 'Jowl kevin shank bacon chicken picanha doner pork belly pancetta meatball short loin. Turducken shank kielbasa tail sirloin beef corned beef cow pig bresaola ham hock. Strip steak ham biltong, short ribs andouille doner picanha pancetta. Drumstick andouille prosciutto spare ribs doner venison frankfurter pig short loin shoulder ham hock sausage. Leberkas porchetta shoulder ham pork chop chuck, pork loin capicola fatback. Ham landjaeger ham hock, spare ribs rump prosciutto chicken meatball corned beef chuck jowl.\r\n\r\n', 56, '8.99', '', 'X-SMALL:SMALL:MEDIUM:LARGE', 'Rump prosciutto chicken meatball corned beef chuck jowl.\r\n\r\n'),
('Chaps Surplice Empire Evening Dress', 553799, 'Bacon ipsum dolor amet beef sirloin beef ribs spare ribs, jerky pig swine strip steak meatloaf ball tip. Chicken shankle venison doner. Tenderloin kielbasa spare ribs corned beef shankle tongue beef tri-tip pork loin turducken alcatra chicken t-bone. Shank boudin rump andouille.\r\n\r\nFatback shoulder ham hock, leberkas pork loin frankfurter kielbasa biltong ball tip filet mignon spare ribs beef ribs alcatra. Ribeye doner venison jowl spare ribs cupim pork chop turducken. Short ribs swine biltong capicola leberkas jerky sirloin kielbasa drumstick chuck pork loin andouille. Tongue turducken corned beef, burgdoggen pastrami short ribs strip steak rump landjaeger pork chop boudin flank. Prosciutto pork chop alcatra ground round tenderloin. Bacon pig kevin shank ham sirloin salami jowl turducken frankfurter beef short loin pork loin.\r\n\r\nSirloin pork short loin, capicola swine cupim andouille shank prosciutto ground round turducken cow turkey. Bacon bresaola salami doner landjaeger. Strip steak sirloin doner alcatra ball tip, turkey pork belly shank shankle beef cupim jowl bacon. Boudin andouille shoulder tail sausage pig kevin drumstick beef ham spare ribs frankfurter.', 5, '15.00', 'Blue:Navy:Black:Mustard:Bronze', 'SMALL:MEDIUM:LARGE', 'Picanha shoulder venison ham hock rump, sirloin ribeye corned beef pig beef ribs ball tip tail.'),
('Running Socks', 567683, 'Fusce at augue a ex suscipit facilisis eget a augue. Quisque consequat eget ante id tincidunt. Sed varius consequat sapien, et iaculis mauris venenatis id. Mauris id nisl placerat, vestibulum quam eu, lobortis mauris. Sed et lacus ut ante mollis lobortis. Fusce malesuada pharetra tortor sed feugiat. Vivamus sit amet purus ac dui sollicitudin varius vel ut erat. Nunc sagittis ut magna sed sollicitudin. Proin ornare porta ligula, sit amet efficitur tortor accumsan quis.', 27, '20.89', '', '', 'Fusce at augue a ex suscipit facilisis eget a augue. Quisque consequat eget ante id tincidunt.'),
('Infinity Scarf', 678096, 'Curabitur lorem turpis, consequat in tempor ac, porta nec eros. Nullam non fringilla nulla. Nunc posuere interdum neque quis porta. Pellentesque congue arcu erat. Mauris tempor mi in ligula aliquet condimentum. Curabitur vel dui purus. Nam dignissim mollis velit, nec imperdiet tellus molestie at. Integer risus elit, tristique id velit eget, egestas ornare ante. Sed et consectetur nisl. Integer ac ipsum mauris. Nullam porttitor fermentum justo non auctor. Etiam cursus, metus in tincidunt luctus, ex est volutpat neque, et feugiat ex quam vitae elit.', 10, '5.99', 'Orange:Purple:Blue:Green:Red', '', ' Vivamus sit amet purus ac dui sollicitudin varius vel ut erat. '),
('Running Shoes', 778630, 'Aenean varius vel metus egestas viverra. Cras sed mollis mauris, quis ultrices ante. Vivamus fringilla odio augue, eget tincidunt lorem varius ut. Aliquam tristique vulputate elementum. Duis consequat nunc felis, sed malesuada arcu commodo et. Quisque porttitor dui non diam consectetur facilisis. Aliquam ut lacus sagittis, convallis ex ut, dictum enim. Donec consectetur sapien vitae tortor imperdiet posuere. Nam ut gravida turpis, sit amet venenatis augue. Duis congue massa eu turpis laoreet, id euismod nisi blandit. Donec tempus nulla at augue consectetur, nec dictum dui condimentum. Donec ornare fermentum orci, vitae euismod lacus cursus bibendum. Suspendisse feugiat, mauris id tempor consectetur, massa leo accumsan lectus, eget accumsan ipsum mi a odio. Vivamus ante diam, hendrerit non vulputate a, consectetur pulvinar elit.\r\n\r\nIn sem tellus, lobortis eu auctor non, efficitur eget lorem. Suspendisse tempor ornare dapibus. Nunc et odio eget urna egestas posuere. Ut laoreet viverra tellus. Nulla faucibus arcu metus, sed blandit nibh rutrum vel. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Pellentesque suscipit pulvinar velit vitae accumsan.', 0, '12.50', '', 'Small:Medium:Large', ' Nunc congue ullamcorper tortor, sed malesuada lorem pellentesque non.'),
('Evening Dress', 782030, 'Ut pulvinar eleifend est blandit ullamcorper. Etiam vel volutpat lacus. In hac habitasse platea dictumst. Duis sagittis blandit mauris in auctor. Sed quis mattis eros, quis tempus nisl. Quisque nunc augue, consequat nec nibh et, finibus cursus nisl. Nunc interdum fermentum elit, non luctus neque venenatis sed. Nunc vestibulum felis arcu, in vehicula mi tempus sed. Morbi congue quam nec tortor mattis, in consequat tellus faucibus. Sed sollicitudin porta nunc non suscipit. Interdum et malesuada fames ac ante ipsum primis in faucibus. Etiam ligula nunc, cursus a ipsum et, sagittis mollis nulla. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Duis pellentesque et quam id sollicitudin. Duis facilisis nunc sem, id fermentum libero lobortis quis. Integer et velit finibus, maximus risus et, iaculis augue.', 19, '15.99', 'Black:Blue', 'X-SMALL:SMALL:MEDIUM:LARGE:X-LARGE', 'Mauris posuere sodales ligula non dapibus. In aliquet arcu non orci tincidunt rutrum. '),
('Cold Shoulder Fit and Flare', 928352, 'Jowl kevin shank bacon chicken picanha doner pork belly pancetta meatball short loin. Turducken shank kielbasa tail sirloin beef corned beef cow pig bresaola ham hock. Strip steak ham biltong, short ribs andouille doner picanha pancetta. Drumstick andouille prosciutto spare ribs doner venison frankfurter pig short loin shoulder ham hock sausage. Leberkas porchetta shoulder ham pork chop chuck, pork loin capicola fatback. Ham landjaeger ham hock, spare ribs rump prosciutto chicken meatball corned beef chuck jowl.', 25, '51', 'Black:Orange:Blue', 'SMALL:MEDIUM:LARGE', 'Pig tail jerky, fatback sausage boudin rump. ');

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `review_number` int(11) NOT NULL,
  `review_product` int(11) NOT NULL,
  `review_name` varchar(500) NOT NULL,
  `review` text NOT NULL,
  `review_date` date NOT NULL,
  `review_rating` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`review_number`, `review_product`, `review_name`, `review`, `review_date`, `review_rating`) VALUES
(1, 778630, 'Brooke', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque pulvinar felis ex, ut pulvinar velit suscipit ac. Nulla orci eros, pharetra eu sagittis non, mattis sit amet felis. Donec pretium felis dui, commodo varius felis elementum a. Integer posuere risus et augue lobortis, at sagittis ligula interdum. In sagittis elit feugiat massa tristique, vel mollis quam interdum. Duis elit nisi, hendrerit convallis odio in, fermentum consectetur risus. Maecenas ornare odio id sapien semper, sed gravida sapien ultricies. Praesent sodales gravida viverra. Aenean sed lacus nec metus placerat aliquam id quis diam.\r\n\r\n', '2016-09-17', 3),
(2, 778630, 'Caleb', 'Quisque sodales lectus in vulputate tincidunt. Nunc sed eros porta, pharetra sapien id, sollicitudin leo. Nam erat quam, ultrices eget sem a, tempor posuere nunc. Integer in erat vestibulum, congue libero in, vestibulum felis. Cras dictum, metus vitae tempus laoreet, nunc magna vulputate ipsum, et dictum sapien mi vel tortor. Mauris cursus nec sem ut varius. Sed pulvinar turpis nec odio bibendum pellentesque. Sed rhoncus, magna quis varius malesuada, metus justo semper risus, et dapibus turpis nisl in velit. Cras rhoncus, elit vel cursus blandit, lacus urna vestibulum velit, eget imperdiet ex ante id tellus. Praesent at libero a augue euismod volutpat placerat vitae metus.\r\n\r\nCum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Duis viverra non mi id tempor. Donec vehicula ante lobortis congue volutpat. Vivamus rutrum mauris sit amet pellentesque efficitur. Proin sed venenatis enim, eget consequat ante. Donec dignissim est quis erat rutrum scelerisque. Vestibulum sed luctus nibh. Etiam neque turpis, pharetra quis lorem quis, venenatis sollicitudin tellus. Fusce nisl tellus, luctus sed auctor et, tincidunt at quam. Nulla mattis sapien nibh, auctor pulvinar magna posuere sed. Ut sodales sapien eu \r\n\r\norci egestas, ut ornare velit sagittis. Nullam non placerat justo.\r\nCum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Duis viverra non mi id tempor. Donec vehicula ante lobortis congue volutpat. Vivamus rutrum mauris sit amet pellentesque efficitur. Proin sed venenatis enim, eget consequat ante. Donec dignissim est quis erat rutrum scelerisque. Vestibulum sed luctus nibh. Etiam neque turpis, pharetra quis lorem quis, venenatis sollicitudin tellus. Fusce nisl tellus, luctus sed auctor et, tincidunt at quam. Nulla mattis sapien nibh, auctor pulvinar magna posuere sed. Ut sodales sapien eu orci egestas, ut ornare velit sagittis. Nullam non placerat justo.', '2016-09-04', 5),
(3, 778630, 'Sarah', 'Quisque sodales lectus in vulputate tincidunt. Nunc sed eros porta, pharetra sapien id, sollicitudin leo. Nam erat quam, ultrices eget sem a, tempor posuere nunc. Integer in erat vestibulum, congue libero in, vestibulum felis. Cras dictum, metus vitae tempus laoreet, nunc magna vulputate ipsum, et dictum sapien mi vel tortor. Mauris cursus nec sem ut varius. Sed pulvinar turpis nec odio bibendum pellentesque. Sed rhoncus, magna quis varius malesuada, metus justo semper risus, et dapibus turpis nisl in velit. Cras rhoncus, elit vel cursus blandit, lacus urna vestibulum velit, eget imperdiet ex ante id tellus. Praesent at libero a augue euismod volutpat placerat vitae metus.\r\nQuisque sodales lectus in vulputate tincidunt. Nunc sed eros porta, pharetra sapien id, sollicitudin leo. Nam erat quam, ultrices eget sem a, tempor posuere nunc. Integer in erat vestibulum, congue libero in, vestibulum felis. Cras dictum, metus vitae tempus laoreet, nunc magna vulputate ipsum, et dictum sapien mi vel tortor. Mauris cursus nec sem ut varius. Sed pulvinar turpis nec odio bibendum pellentesque. Sed rhoncus, magna quis varius malesuada, metus justo semper risus, et dapibus turpis nisl in velit. Cras rhoncus, elit vel cursus blandit, lacus urna vestibulum velit, eget imperdiet ex ante id tellus. Praesent at libero a augue euismod volutpat placerat vitae metus.\r\nQuisque sodales lectus in vulputate tincidunt. Nunc sed eros porta, pharetra sapien id, sollicitudin leo. Nam erat quam, ultrices eget sem a, tempor posuere nunc. Integer in erat vestibulum, congue libero in, vestibulum felis. Cras dictum, metus vitae tempus laoreet, nunc magna vulputate ipsum, et dictum sapien mi vel tortor. Mauris cursus nec sem ut varius. Sed pulvinar turpis nec odio bibendum pellentesque. Sed rhoncus, magna quis varius malesuada, metus justo semper risus, et dapibus turpis nisl in velit. Cras rhoncus, elit vel cursus blandit, lacus urna vestibulum velit, eget imperdiet ex ante id tellus. Praesent at libero a augue euismod volutpat placerat vitae metus.\r\n\r\nCum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Duis viverra non mi id tempor. Donec vehicula ante lobortis congue volutpat. Vivamus rutrum mauris sit amet pellentesque efficitur. Proin sed venenatis enim, eget consequat ante. Donec dignissim est quis erat rutrum scelerisque. Vestibulum sed luctus nibh. Etiam neque turpis, pharetra quis lorem quis, venenatis sollicitudin tellus. Fusce nisl tellus, luctus sed auctor et, tincidunt at quam. Nulla mattis sapien nibh, auctor pulvinar magna posuere sed. Ut sodales sapien eu \r\n\r\norci egestas, ut ornare velit sagittis. Nullam non placerat justo.\r\nCum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Duis viverra non mi id tempor. Donec vehicula ante lobortis congue volutpat. Vivamus rutrum mauris sit amet pellentesque efficitur. Proin sed venenatis enim, eget consequat ante. Donec dignissim est quis erat rutrum scelerisque. Vestibulum sed luctus nibh. Etiam neque turpis, pharetra quis lorem quis, venenatis sollicitudin tellus. Fusce nisl tellus, luctus sed auctor et, tincidunt at quam. Nulla mattis sapien nibh, auctor pulvinar magna posuere sed. Ut sodales sapien eu orci egestas, ut ornare velit sagittis. Nullam non placerat justo.', '2017-02-13', 2),
(6, 342527, 'Joel', 'Brisket kevin kielbasa sirloin. Pork tongue cupim salami shoulder, porchetta kevin chicken leberkas t-bone beef ribs jerky doner. Salami pastrami ball tip ribeye, capicola pork loin pig leberkas spare ribs filet mignon prosciutto. Pork cupim chuck pig sirloin beef ribs leberkas kielbasa pork loin t-bone meatball doner short ribs ribeye. Burgdoggen shoulder turducken prosciutto tri-tip spare ribs beef t-bone picanha cupim. Pastrami pork meatloaf turkey pork loin beef beef ribs ground round doner jerky brisket strip steak kevin ball tip. Drumstick turkey ribeye, strip steak sausage andouille biltong cupim bresaola jerky beef ribs short loin cow shank.', '2017-02-23', 3),
(7, 373940, 'Jack', 'Brisket kevin kielbasa sirloin. Pork tongue cupim salami shoulder, porchetta kevin chicken leberkas t-bone beef ribs jerky doner. Salami pastrami ball tip ribeye, capicola pork loin pig leberkas spare ribs filet mignon prosciutto. Pork cupim chuck pig sirloin beef ribs leberkas kielbasa pork loin t-bone meatball doner short ribs ribeye. Burgdoggen shoulder turducken prosciutto tri-tip spare ribs beef t-bone picanha cupim. Pastrami pork meatloaf turkey pork loin beef beef ribs ground round doner jerky brisket strip steak kevin ball tip. Drumstick turkey ribeye, strip steak sausage andouille biltong cupim bresaola jerky beef ribs short loin cow shank.Brisket kevin kielbasa sirloin. Pork tongue cupim salami shoulder, porchetta kevin chicken leberkas t-bone beef ribs jerky doner. Salami pastrami ball tip ribeye, capicola pork loin pig leberkas spare ribs filet mignon prosciutto. Pork cupim chuck pig sirloin beef ribs leberkas kielbasa pork loin t-bone meatball doner short ribs ribeye. Burgdoggen shoulder turducken prosciutto tri-tip spare ribs beef t-bone picanha cupim. Pastrami pork meatloaf turkey pork loin beef beef ribs ground round doner jerky brisket strip steak kevin ball tip. Drumstick turkey ribeye, strip steak sausage andouille biltong cupim bresaola jerky beef ribs short loin cow shank.', '2017-02-22', 4),
(8, 523241, 'Debbi', 'Drumstick cupim tail bresaola ground round porchetta sausage jerky. Leberkas short ribs cupim turducken, rump salami tail chuck burgdoggen jerky jowl picanha shank. Pancetta alcatra beef shoulder turkey, pork chop short loin t-bone pork belly. Burgdoggen corned beef pastrami, meatball doner cupim andouille landjaeger. Tail prosciutto jerky ham hock ball tip biltong alcatra. Meatball ribeye flank, jerky beef filet mignon brisket.\r\n\r\nFatback meatball frankfurter tongue pork cow beef ribs prosciutto rump t-bone. Shoulder shankle brisket beef ribs corned beef prosciutto. Jerky strip steak cupim hamburger tri-tip filet mignon bresaola ball tip swine chicken pork pastrami chuck. Turkey andouille tongue meatball, swine ground round shank brisket venison salami ribeye.', '2017-02-02', 5),
(9, 553799, 'Patrick', 'Bacon ipsum dolor amet beef sirloin beef ribs spare ribs, jerky pig swine strip steak meatloaf ball tip. Chicken shankle venison doner. Tenderloin kielbasa spare ribs corned beef shankle tongue beef tri-tip pork loin turducken alcatra chicken t-bone. Shank boudin rump andouille.\r\n\r\nFatback shoulder ham hock, leberkas pork loin frankfurter kielbasa biltong ball tip filet mignon spare ribs beef ribs alcatra. Ribeye doner venison jowl spare ribs cupim pork chop turducken. Short ribs swine biltong capicola leberkas jerky sirloin kielbasa drumstick chuck pork loin andouille. Tongue turducken corned beef, burgdoggen pastrami short ribs strip steak rump landjaeger pork chop boudin flank. Prosciutto pork chop alcatra ground round tenderloin. Bacon pig kevin shank ham sirloin salami jowl turducken frankfurter beef short loin pork loin.\r\n\r\nSirloin pork short loin, capicola swine cupim andouille shank prosciutto ground round turducken cow turkey. Bacon bresaola salami doner landjaeger. Strip steak sirloin doner alcatra ball tip, turkey pork belly shank shankle beef cupim jowl bacon. Boudin andouille shoulder tail sausage pig kevin drumstick beef ham spare ribs frankfurter.\r\n\r\nPicanha shoulder venison ham hock rump, sirloin ribeye corned beef pig beef ribs ball tip tail. Turducken tri-tip kielbasa flank filet mignon brisket. Pig tail jerky, fatback sausage boudin rump. Ribeye rump salami, sausage capicola turkey boudin kielbasa swine ball tip bresaola short ribs ground round.\r\n\r\nLandjaeger frankfurter kielbasa filet mignon tri-tip turducken. Fatback drumstick short ribs tri-tip, sirloin ham hock pork chop shoulder ribeye t-bone. Biltong turkey pork chicken porchetta frankfurter ribeye shoulder boudin sirloin corned beef chuck hamburger. Burgdoggen drumstick pork loin kielbasa pork belly ham hock.\r\n\r\nSausage burgdoggen shoulder, jerky tail flank short ribs shank porchetta cow. Frankfurter swine jowl short loin salami pork belly pork short ribs meatloaf ham hock shoulder. Meatball flank brisket short ribs. Porchetta ground round doner pastrami landjaeger, brisket jowl. Rump strip steak leberkas, ribeye spare ribs hamburger pig kevin t-bone beef ribs bresaola flank corned beef prosciutto cow.\r\n\r\nKevin shank brisket ribeye bresaola burgdoggen chicken short ribs andouille alcatra pancetta. Doner corned beef pig alcatra short loin strip steak tri-tip boudin turducken. Picanha chicken pork chop, tongue fatback turkey rump. Cow corned beef pork, biltong pancetta leberkas cupim meatball. Hamburger bresaola sirloin, tenderloin cupim pork belly ham hock alcatra tongue jerky beef ribs bacon turducken. Porchetta sausage hamburger, alcatra jerky meatloaf pork belly drumstick.\r\n\r\nBiltong rump tail, spare ribs sausage chuck jerky capicola ribeye drumstick. Pork belly alcatra ground round, spare ribs frankfurter shank flank kielbasa tail tri-tip andouille short loin. Pancetta pig picanha, cupim biltong kevin bresaola chicken andouille pork loin tri-tip porchetta filet mignon. Drumstick doner cupim turducken shank chuck pork loin shankle rump corned beef pancetta alcatra pig. Swine jowl shank biltong cupim pork sausage doner short ribs ground round turducken tenderloin. Pig sausage spare ribs cupim capicola tenderloin.\r\n\r\nCow alcatra cupim, fatback pork loin ground round ball tip ham short loin meatloaf tenderloin sirloin pig hamburger. Biltong venison pork belly cupim, leberkas capicola porchetta andouille short ribs. Swine andouille sausage pork chop venison short ribs. Kielbasa turkey brisket tenderloin bresaola corned beef biltong kevin, pig tri-tip ground round beef ribs pork loin jerky venison. Tongue pork shankle kielbasa, pancetta strip steak kevin.\r\n\r\nJowl kevin shank bacon chicken picanha doner pork belly pancetta meatball short loin. Turducken shank kielbasa tail sirloin beef corned beef cow pig bresaola ham hock. Strip steak ham biltong, short ribs andouille doner picanha pancetta. Drumstick andouille prosciutto spare ribs doner venison frankfurter pig short loin shoulder ham hock sausage. Leberkas porchetta shoulder ham pork chop chuck, pork loin capicola fatback. Ham landjaeger ham hock, spare ribs rump prosciutto chicken meatball corned beef chuck jowl.\r\n\r\nJowl filet mignon shank cow, sirloin beef ribs ball tip ribeye chuck pork andouille salami pancetta leberkas tail. Filet mignon beef ribs tail pork biltong jowl fatback pork loin bresaola pork belly pig jerky short ribs spare ribs pastrami. Kielbasa salami jowl prosciutto ham beef. Cow meatball bresaola boudin ham. Hamburger kielbasa picanha tenderloin.\r\n\r\nFrankfurter short loin tenderloin sausage doner pork chop cow ground round picanha shank t-bone shankle. Leberkas bacon pork cow cupim tri-tip shankle corned beef chuck picanha biltong ham sausage tail. Drumstick pork loin jowl, ribeye landjaeger andouille burgdoggen shoulder jerky corned beef leberkas. Bacon sausage doner jowl beef ribs sirloin. Flank sirloin swine cupim kielbasa pork belly tongue pork pastrami. Fatback shankle turkey sausage bacon biltong, chicken short ribs tail salami landjaeger cow picanha strip steak.\r\n\r\nShoulder tenderloin ground round shank capicola kielbasa short loin. Landjaeger kevin bacon shankle ground round short ribs pork chop flank fatback picanha bresaola strip steak sirloin turducken short loin. Swine porchetta boudin landjaeger, chicken cow jerky hamburger venison biltong shankle pig leberkas. Flank pork cow, frankfurter leberkas capicola brisket alcatra fatback sirloin shankle ribeye. Strip steak t-bone pastrami tri-tip boudin, tongue sirloin venison prosciutto frankfurter shank. Jowl sirloin rump bacon ground round beef shankle short loin turkey pork belly. Ham shankle short loin hamburger.\r\n\r\nBeef fatback ribeye, ball tip picanha prosciutto short ribs short loin pastrami pork loin burgdoggen cupim meatball turkey. Turducken biltong chicken bacon pork loin pork belly ball tip pancetta. Pork loin meatball boudin, tongue short loin shoulder landjaeger pork belly ham hock chicken ball tip. Capicola turducken boudin salami, tri-tip pastrami beef tail.\r\n\r\nLandjaeger pig porchetta salami frankfurter, turducken burgdoggen swine alcatra venison leberkas pastrami bresaola. T-bone tongue tri-tip ground round. Tongue jowl porchetta ground round venison. Meatball cow shankle pork pork belly, kevin bresaola jerky drumstick pastrami strip steak venison tenderloin meatloaf frankfurter. Ham alcatra pork loin andouille sausage short ribs shank fatback sirloin kevin ball tip spare ribs jowl ham hock. Tail pork belly meatball, ribeye picanha porchetta hamburger pork chop chuck frankfurter. Jowl frankfurter short ribs prosciutto, sirloin tail meatloaf.\r\n\r\nBrisket shank pork loin, spare ribs kevin short ribs biltong venison. Pastrami tri-tip bresaola, pig alcatra bacon beef ribs. Capicola porchetta pork loin frankfurter pancetta. Short loin beef tri-tip shank pork loin. Cow filet mignon rump, biltong meatloaf pancetta hamburger. Shoulder fatback biltong, short ribs turducken ball tip filet mignon salami short loin beef pig shank.\r\n\r\nBrisket kevin kielbasa sirloin. Pork tongue cupim salami shoulder, porchetta kevin chicken leberkas t-bone beef ribs jerky doner. Salami pastrami ball tip ribeye, capicola pork loin pig leberkas spare ribs filet mignon prosciutto. Pork cupim chuck pig sirloin beef ribs leberkas kielbasa pork loin t-bone meatball doner short ribs ribeye. Burgdoggen shoulder turducken prosciutto tri-tip spare ribs beef t-bone picanha cupim. Pastrami pork meatloaf turkey pork loin beef beef ribs ground round doner jerky brisket strip steak kevin ball tip. Drumstick turkey ribeye, strip steak sausage andouille biltong cupim bresaola jerky beef ribs short loin cow shank.\r\n\r\nSausage pork belly andouille frankfurter pork beef. Bacon short ribs capicola, fatback andouille cow cupim pastrami beef tri-tip ham flank rump. Porchetta capicola t-bone, shank frankfurter corned beef tail kielbasa. T-bone strip steak biltong pancetta. Leberkas meatloaf corned beef drumstick, capicola beef ribs venison short ribs.', '2017-02-12', 1),
(10, 928352, 'Patrice', 'Drumstick cupim tail bresaola ground round porchetta sausage jerky. Leberkas short ribs cupim turducken, rump salami tail chuck burgdoggen jerky jowl picanha shank. Pancetta alcatra beef shoulder turkey, pork chop short loin t-bone pork belly. Burgdoggen corned beef pastrami, meatball doner cupim andouille landjaeger. Tail prosciutto jerky ham hock ball tip biltong alcatra. Meatball ribeye flank, jerky beef filet mignon brisket.\r\n\r\nFatback meatball frankfurter tongue pork cow beef ribs prosciutto rump t-bone. Shoulder shankle brisket beef ribs corned beef prosciutto. Jerky strip steak cupim hamburger tri-tip filet mignon bresaola ball tip swine chicken pork pastrami chuck. Turkey andouille tongue meatball, swine ground round shank brisket venison salami ribeye.', '2017-01-16', 5),
(11, 553799, 'Matthew', 'Bacon ipsum dolor amet beef sirloin beef ribs spare ribs, jerky pig swine strip steak meatloaf ball tip. Chicken shankle venison doner. Tenderloin kielbasa spare ribs corned beef shankle tongue beef tri-tip pork loin turducken alcatra chicken t-bone. Shank boudin rump andouille.\r\n\r\nFatback shoulder ham hock, leberkas pork loin frankfurter kielbasa biltong ball tip filet mignon spare ribs beef ribs alcatra. Ribeye doner venison jowl spare ribs cupim pork chop turducken. Short ribs swine biltong capicola leberkas jerky sirloin kielbasa drumstick chuck pork loin andouille. Tongue turducken corned beef, burgdoggen pastrami short ribs strip steak rump landjaeger pork chop boudin flank. Prosciutto pork chop alcatra ground round tenderloin. Bacon pig kevin shank ham sirloin salami jowl turducken frankfurter beef short loin pork loin.\r\n\r\nSirloin pork short loin, capicola swine cupim andouille shank prosciutto ground round turducken cow turkey. Bacon bresaola salami doner landjaeger. Strip steak sirloin doner alcatra ball tip, turkey pork belly shank shankle beef cupim jowl bacon. Boudin andouille shoulder tail sausage pig kevin drumstick beef ham spare ribs frankfurter.\r\n\r\nPicanha shoulder venison ham hock rump, sirloin ribeye corned beef pig beef ribs ball tip tail. Turducken tri-tip kielbasa flank filet mignon brisket. Pig tail jerky, fatback sausage boudin rump. Ribeye rump salami, sausage capicola turkey boudin kielbasa swine ball tip bresaola short ribs ground round.\r\n\r\nLandjaeger frankfurter kielbasa filet mignon tri-tip turducken. Fatback drumstick short ribs tri-tip, sirloin ham hock pork chop shoulder ribeye t-bone. Biltong turkey pork chicken porchetta frankfurter ribeye shoulder boudin sirloin corned beef chuck hamburger. Burgdoggen drumstick pork loin kielbasa pork belly ham hock.\r\n\r\nSausage burgdoggen shoulder, jerky tail flank short ribs shank porchetta cow. Frankfurter swine jowl short loin salami pork belly pork short ribs meatloaf ham hock shoulder. Meatball flank brisket short ribs. Porchetta ground round doner pastrami landjaeger, brisket jowl. Rump strip steak leberkas, ribeye spare ribs hamburger pig kevin t-bone beef ribs bresaola flank corned beef prosciutto cow.\r\n\r\nKevin shank brisket ribeye bresaola burgdoggen chicken short ribs andouille alcatra pancetta. Doner corned beef pig alcatra short loin strip steak tri-tip boudin turducken. Picanha chicken pork chop, tongue fatback turkey rump. Cow corned beef pork, biltong pancetta leberkas cupim meatball. Hamburger bresaola sirloin, tenderloin cupim pork belly ham hock alcatra tongue jerky beef ribs bacon turducken. Porchetta sausage hamburger, alcatra jerky meatloaf pork belly drumstick.\r\n\r\nBiltong rump tail, spare ribs sausage chuck jerky capicola ribeye drumstick. Pork belly alcatra ground round, spare ribs frankfurter shank flank kielbasa tail tri-tip andouille short loin. Pancetta pig picanha, cupim biltong kevin bresaola chicken andouille pork loin tri-tip porchetta filet mignon. Drumstick doner cupim turducken shank chuck pork loin shankle rump corned beef pancetta alcatra pig. Swine jowl shank biltong cupim pork sausage doner short ribs ground round turducken tenderloin. Pig sausage spare ribs cupim capicola tenderloin.\r\n\r\nCow alcatra cupim, fatback pork loin ground round ball tip ham short loin meatloaf tenderloin sirloin pig hamburger. Biltong venison pork belly cupim, leberkas capicola porchetta andouille short ribs. Swine andouille sausage pork chop venison short ribs. Kielbasa turkey brisket tenderloin bresaola corned beef biltong kevin, pig tri-tip ground round beef ribs pork loin jerky venison. Tongue pork shankle kielbasa, pancetta strip steak kevin.\r\n\r\nJowl kevin shank bacon chicken picanha doner pork belly pancetta meatball short loin. Turducken shank kielbasa tail sirloin beef corned beef cow pig bresaola ham hock. Strip steak ham biltong, short ribs andouille doner picanha pancetta. Drumstick andouille prosciutto spare ribs doner venison frankfurter pig short loin shoulder ham hock sausage. Leberkas porchetta shoulder ham pork chop chuck, pork loin capicola fatback. Ham landjaeger ham hock, spare ribs rump prosciutto chicken meatball corned beef chuck jowl.\r\n\r\nJowl filet mignon shank cow, sirloin beef ribs ball tip ribeye chuck pork andouille salami pancetta leberkas tail. Filet mignon beef ribs tail pork biltong jowl fatback pork loin bresaola pork belly pig jerky short ribs spare ribs pastrami. Kielbasa salami jowl prosciutto ham beef. Cow meatball bresaola boudin ham. Hamburger kielbasa picanha tenderloin.\r\n\r\nFrankfurter short loin tenderloin sausage doner pork chop cow ground round picanha shank t-bone shankle. Leberkas bacon pork cow cupim tri-tip shankle corned beef chuck picanha biltong ham sausage tail. Drumstick pork loin jowl, ribeye landjaeger andouille burgdoggen shoulder jerky corned beef leberkas. Bacon sausage doner jowl beef ribs sirloin. Flank sirloin swine cupim kielbasa pork belly tongue pork pastrami. Fatback shankle turkey sausage bacon biltong, chicken short ribs tail salami landjaeger cow picanha strip steak.\r\n\r\nShoulder tenderloin ground round shank capicola kielbasa short loin. Landjaeger kevin bacon shankle ground round short ribs pork chop flank fatback picanha bresaola strip steak sirloin turducken short loin. Swine porchetta boudin landjaeger, chicken cow jerky hamburger venison biltong shankle pig leberkas. Flank pork cow, frankfurter leberkas capicola brisket alcatra fatback sirloin shankle ribeye. Strip steak t-bone pastrami tri-tip boudin, tongue sirloin venison prosciutto frankfurter shank. Jowl sirloin rump bacon ground round beef shankle short loin turkey pork belly. Ham shankle short loin hamburger.\r\n\r\nBeef fatback ribeye, ball tip picanha prosciutto short ribs short loin pastrami pork loin burgdoggen cupim meatball turkey. Turducken biltong chicken bacon pork loin pork belly ball tip pancetta. Pork loin meatball boudin, tongue short loin shoulder landjaeger pork belly ham hock chicken ball tip. Capicola turducken boudin salami, tri-tip pastrami beef tail.\r\n\r\nLandjaeger pig porchetta salami frankfurter, turducken burgdoggen swine alcatra venison leberkas pastrami bresaola. T-bone tongue tri-tip ground round. Tongue jowl porchetta ground round venison. Meatball cow shankle pork pork belly, kevin bresaola jerky drumstick pastrami strip steak venison tenderloin meatloaf frankfurter. Ham alcatra pork loin andouille sausage short ribs shank fatback sirloin kevin ball tip spare ribs jowl ham hock. Tail pork belly meatball, ribeye picanha porchetta hamburger pork chop chuck frankfurter. Jowl frankfurter short ribs prosciutto, sirloin tail meatloaf.\r\n\r\nBrisket shank pork loin, spare ribs kevin short ribs biltong venison. Pastrami tri-tip bresaola, pig alcatra bacon beef ribs. Capicola porchetta pork loin frankfurter pancetta. Short loin beef tri-tip shank pork loin. Cow filet mignon rump, biltong meatloaf pancetta hamburger. Shoulder fatback biltong, short ribs turducken ball tip filet mignon salami short loin beef pig shank.\r\n\r\nBrisket kevin kielbasa sirloin. Pork tongue cupim salami shoulder, porchetta kevin chicken leberkas t-bone beef ribs jerky doner. Salami pastrami ball tip ribeye, capicola pork loin pig leberkas spare ribs filet mignon prosciutto. Pork cupim chuck pig sirloin beef ribs leberkas kielbasa pork loin t-bone meatball doner short ribs ribeye. Burgdoggen shoulder turducken prosciutto tri-tip spare ribs beef t-bone picanha cupim. Pastrami pork meatloaf turkey pork loin beef beef ribs ground round doner jerky brisket strip steak kevin ball tip. Drumstick turkey ribeye, strip steak sausage andouille biltong cupim bresaola jerky beef ribs short loin cow shank.\r\n\r\nSausage pork belly andouille frankfurter pork beef. Bacon short ribs capicola, fatback andouille cow cupim pastrami beef tri-tip ham flank rump. Porchetta capicola t-bone, shank frankfurter corned beef tail kielbasa. T-bone strip steak biltong pancetta. Leberkas meatloaf corned beef drumstick, capicola beef ribs venison short ribs.', '2017-01-25', 1);

-- --------------------------------------------------------

--
-- Table structure for table `shipping`
--

CREATE TABLE `shipping` (
  `shipping_id` int(11) NOT NULL,
  `shipping_username` varchar(50) NOT NULL,
  `shipping_name` varchar(50) NOT NULL,
  `shipping_street` longtext NOT NULL,
  `shipping_state` varchar(2) NOT NULL,
  `shipping_zip` int(7) NOT NULL,
  `shipping_city` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `shipping`
--

INSERT INTO `shipping` (`shipping_id`, `shipping_username`, `shipping_name`, `shipping_street`, `shipping_state`, `shipping_zip`, `shipping_city`) VALUES
(1, 'bbailey', 'Brooke Bailey', '20350 Shady Acres Drive', 'VA', 22856, 'Elkton'),
(2, 'bbailey', 'Sarah', '2363840', 'CA', 32434, 'Denver'),
(3, 'SarahB', 'Sarah', '5678 South Main Street', 'AZ', 354675, 'Pheonix'),
(4, 'Mathias-the-great', 'Mathias Walters', '5689 East Side Highway', 'VA', 22801, 'Harrisonburg'),
(5, 'Mathias-the-great', 'Mathias Walters', '5689 East Side Highway', 'VA', 22801, 'Harrisonburg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user` text NOT NULL,
  `screenname` varchar(30) DEFAULT NULL,
  `user_email` text NOT NULL,
  `user_dob` date NOT NULL,
  `user_phone_number` text NOT NULL,
  `user_password` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user`, `screenname`, `user_email`, `user_dob`, `user_phone_number`, `user_password`) VALUES
('Brooke Bailey', 'bbailey', 'brookeobailey@gmail.com', '1991-11-20', '540-209-7411', '25f9e794323b453885f5181f1b624d0b'),
('Jamie', 'cuy-girl', 'hello@example.com', '1990-09-11', '6387673564', '25f9e794323b453885f5181f1b624d0b'),
('Sarah', 'SarahB', 'sarah@gmail.com', '1990-03-17', '3546735269', '25f9e794323b453885f5181f1b624d0b'),
('Martin', 'Marty', 'marty@aol.com', '1978-11-15', '6548791498', '25f9e794323b453885f5181f1b624d0b'),
('Mathias', 'Mathias-the-great', 'mathiasTheGreat@gmail.com', '1976-12-23', '7869824509', '25f9e794323b453885f5181f1b624d0b');

-- --------------------------------------------------------

--
-- Table structure for table `wishlist`
--

CREATE TABLE `wishlist` (
  `wishlist_id` int(11) NOT NULL,
  `user` varchar(50) NOT NULL,
  `product_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `wishlist`
--

INSERT INTO `wishlist` (`wishlist_id`, `user`, `product_id`) VALUES
(1, 'bbailey', 782030);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `billing`
--
ALTER TABLE `billing`
  ADD PRIMARY KEY (`billing_id`),
  ADD KEY `billing_id` (`billing_id`),
  ADD KEY `billing_username` (`billing_username`),
  ADD KEY `billing_username_2` (`billing_username`),
  ADD KEY `billing_username_3` (`billing_username`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`cart_id`),
  ADD KEY `cart_id` (`cart_id`),
  ADD KEY `product_id` (`product_id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `username` (`username`),
  ADD KEY `order_id_2` (`order_id`),
  ADD KEY `order_id_3` (`order_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `billing_id` (`billing_id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `billing_id_2` (`billing_id`),
  ADD KEY `shipping_id` (`shipping_id`),
  ADD KEY `payment_id` (`payment_id`),
  ADD KEY `username` (`username`),
  ADD KEY `order_id_2` (`order_id`),
  ADD KEY `shipping_id_2` (`shipping_id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`payment_id`),
  ADD KEY `payment_id` (`payment_id`),
  ADD KEY `payment_username` (`payment_username`),
  ADD KEY `payment_id_2` (`payment_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`),
  ADD UNIQUE KEY `product_id` (`product_id`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`review_number`),
  ADD KEY `review_product` (`review_product`),
  ADD KEY `review_name` (`review_name`(191));

--
-- Indexes for table `shipping`
--
ALTER TABLE `shipping`
  ADD PRIMARY KEY (`shipping_id`),
  ADD KEY `shipping_username` (`shipping_username`),
  ADD KEY `shipping_id` (`shipping_id`),
  ADD KEY `shipping_username_2` (`shipping_username`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD UNIQUE KEY `screenname` (`screenname`),
  ADD KEY `screenname_2` (`screenname`);

--
-- Indexes for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD UNIQUE KEY `wishlist_id` (`wishlist_id`),
  ADD KEY `user` (`user`),
  ADD KEY `wishlist_id_2` (`wishlist_id`),
  ADD KEY `product_id` (`product_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `billing`
--
ALTER TABLE `billing`
  MODIFY `billing_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `cart_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;
--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;
--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `review_number` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `shipping`
--
ALTER TABLE `shipping`
  MODIFY `shipping_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `wishlist`
--
ALTER TABLE `wishlist`
  MODIFY `wishlist_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `billing`
--
ALTER TABLE `billing`
  ADD CONSTRAINT `billing_ibfk_1` FOREIGN KEY (`billing_username`) REFERENCES `users` (`screenname`);

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`username`) REFERENCES `users` (`screenname`),
  ADD CONSTRAINT `cart_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`);

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`username`) REFERENCES `users` (`screenname`),
  ADD CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`billing_id`) REFERENCES `billing` (`billing_id`),
  ADD CONSTRAINT `orders_ibfk_3` FOREIGN KEY (`shipping_id`) REFERENCES `shipping` (`shipping_id`),
  ADD CONSTRAINT `orders_ibfk_4` FOREIGN KEY (`payment_id`) REFERENCES `payment` (`payment_id`);

--
-- Constraints for table `payment`
--
ALTER TABLE `payment`
  ADD CONSTRAINT `payment_ibfk_1` FOREIGN KEY (`payment_username`) REFERENCES `users` (`screenname`);

--
-- Constraints for table `reviews`
--
ALTER TABLE `reviews`
  ADD CONSTRAINT `reviews_ibfk_1` FOREIGN KEY (`review_product`) REFERENCES `products` (`product_id`);

--
-- Constraints for table `shipping`
--
ALTER TABLE `shipping`
  ADD CONSTRAINT `shipping_ibfk_1` FOREIGN KEY (`shipping_username`) REFERENCES `users` (`screenname`);

--
-- Constraints for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD CONSTRAINT `wishlist_ibfk_1` FOREIGN KEY (`user`) REFERENCES `users` (`screenname`),
  ADD CONSTRAINT `wishlist_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
